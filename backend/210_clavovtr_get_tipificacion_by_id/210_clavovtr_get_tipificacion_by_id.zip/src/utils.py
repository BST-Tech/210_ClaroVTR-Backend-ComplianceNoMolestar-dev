def element_to_json(data):
    new_data = []
    for element in data:
        new_data.append({
            "id": element[0],
            "codigo": element[1],
            "descripcion": element[2],
            "contacto": element[3],
            "venta": element[4],
            "id_contactCenter": element[5]
        })
    return new_data
    