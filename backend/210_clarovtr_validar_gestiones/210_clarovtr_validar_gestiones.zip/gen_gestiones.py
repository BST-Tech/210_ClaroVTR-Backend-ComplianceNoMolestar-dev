import csv
import json
from datetime import datetime, timedelta

initial_date = datetime(2024, 1, 28, 10, 6, 30)


def read_csv_and_iterate(file_path: str):
    output = []
    with open(file_path, "r") as csvfile:
        csv_reader = csv.reader(csvfile)

        # Skip the header row if there is one
        header = next(csv_reader, None)
        if header:
            print(f"Header: {header}")

        # Iterate over the remaining rows
        for idx, row in enumerate(csv_reader):
            if row[1] == "OK PARA LLAMAR":
                output.append(row[0])
    return output


def generate_rows(values, offset=0):
    rows = []
    left = ["Latin Center", "Latin Center", "982929115"]
    right = ["Movil", "NC", "10"]
    for i, val in enumerate(values):
        new_date = initial_date + timedelta(minutes=i + offset)
        new_date_str = new_date.strftime("%d-%m-%Y %H:%M:%S")
        row = left + [val, new_date_str] + right
        rows.append(row)
    return rows


def write_sample_gestiones(input_pcs, file_path):
    header = [
        "canal_o_nombre_eps",
        "operador_id_ejecutivo",
        "pcs_salida",
        "pcs_cliente",
        "fecha_llamada",
        "campania",
        "tipificacion",
        "segundos_llamadas",
    ]

    with open(file_path, "w", newline="") as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(header)

    with open(file_path, "a", newline="") as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerows(generate_rows(input_pcs[:-1]))

    with open(file_path, "a", newline="") as csvfile:
        csv_writer = csv.writer(csvfile, lineterminator="")
        csv_writer.writerows(generate_rows([input_pcs[-1]], offset=len(input_pcs)))


def read_gestiones_csv(file_path: str):
    output = []
    with open(file_path, "r") as csvfile:
        csv_reader = csv.reader(csvfile)

        # Skip the header row if there is one
        header = next(csv_reader, None)
        if header:
            print(f"Header: {header}")

        # Iterate over the remaining rows
        for idx, row in enumerate(csv_reader):
            output.append(
                {
                    "canal_o_nombre_EPS": row[0],
                    "operador_id_ejecutivo": row[1],
                    "pcs_salida": row[2],
                    "pcs_cliente": row[3],
                    "fechallamada": row[4],
                    "campania": row[5],
                    "cod_tipificacion": row[6],
                    "duracion_en_segundos": row[7],
                }
            )
    return output


def generate_json_test_case(file_path_csv):
    output = read_gestiones_csv(file_path_csv)
    uid = "9f4482f6-1d52-4f55-a9da-f154b9f9052d"
    id_canal = 1
    id_code = "eee8b019f2a74ccf9fe20518d6a4e9d5"
    list_leads = output
    body = {"uid": uid, "id_canal": id_canal, "cod_carga": id_code, "data": list_leads}
    out_name = file_path_csv.replace(".csv", ".json")
    with open(out_name, "w") as f:
        json.dump(body, f, indent=2)


for input in ["./lead_data_5k.csv", "./lead_data_big.csv"]:
    pcs = read_csv_and_iterate(input)
    csv_outname = input.replace("lead_data", "gestiones")
    print(csv_outname)
    write_sample_gestiones(pcs, csv_outname)
    generate_json_test_case(csv_outname)
